def func_b():
    return 2
