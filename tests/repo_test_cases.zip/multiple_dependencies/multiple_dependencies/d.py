from .c import func_c


def func_d():
    print("D")
    func_c()

