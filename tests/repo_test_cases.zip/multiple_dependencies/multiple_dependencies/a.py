def func_a():
    print("A (new)")
