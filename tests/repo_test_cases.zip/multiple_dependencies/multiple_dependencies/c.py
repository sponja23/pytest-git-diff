from .a import func_a
from .b import func_b

def func_c():
    func_a()
    print("c")
    print(func_b())
