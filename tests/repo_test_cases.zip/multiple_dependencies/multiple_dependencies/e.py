from .b import func_b

def func_e():
    func_b()

    print("E")
