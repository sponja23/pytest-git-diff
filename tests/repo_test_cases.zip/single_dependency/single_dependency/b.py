from .a import func_a

def func_b():
    func_a()
    print("b.py")
