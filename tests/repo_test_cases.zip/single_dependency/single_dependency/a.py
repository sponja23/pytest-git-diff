def func_a():
    print("new a.py")
