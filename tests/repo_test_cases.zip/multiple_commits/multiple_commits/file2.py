print("goodbye world!")
