print("Goodbye, world!")
